import os
import re
import random
import requests
import time
from urllib.parse import urlparse, urljoin
from bs4 import BeautifulSoup
from .common import (
    create_driver, inject_cookies_to_driver, wait_for_page_load, smart_scroll,
    HEADERS, collect_network_images, extract_canvas_images, extract_blob_images,
    screenshot_visible_images, screenshot_images_top_to_bottom, download_collected_images,
    write_extraction_log
)

PIXIV_REFERER = "https://www.pixiv.net/"

def is_pixiv(url: str) -> bool:
    host = (urlparse(url).hostname or "").lower()
    return host == "pixiv.net" or host.endswith(".pixiv.net")

def extract_illust_id(url: str) -> str | None:
    m = re.search(r'/artworks/(\d+)', url)
    if m:
        return m.group(1)
    m = re.search(r'[?&]illust_id=(\d+)', url)
    if m:
        return m.group(1)
    return None

def pixiv_master_to_original(master_url: str) -> list[str]:
    cleaned = re.sub(r'_(master|square|custom|small)\d*', '', master_url)
    original_base = re.sub(
        r'i\.pximg\.net/(img-master|img-inf|img-zip-ugoira|c/\d+x\d+[^/]*/img-master)',
        'i.pximg.net/img-original',
        cleaned
    )
    base_no_ext = re.sub(r'\.(jpe?g|png|webp|gif)$', '', original_base, flags=re.I)
    return [base_no_ext + ext for ext in ['.jpg', '.png', '.webp']]

def pixiv_fetch_via_api(illust_id: str, session: requests.Session) -> list[str]:
    api = f"https://www.pixiv.net/ajax/illust/{illust_id}/pages?lang=ja"
    try:
        r = session.get(api, headers={"Referer": PIXIV_REFERER}, timeout=10)
        if r.status_code != 200: return []
        data = r.json()
        if data.get("error"): return []
        urls = []
        for page in data.get("body", []):
            original = page.get("urls", {}).get("original")
            if original:
                urls.append(original)
        return urls
    except Exception:
        return []

def open_pixiv_all_pages(driver):
    buttons = driver.find_elements("xpath", "//*[self::button or self::a][contains(., 'すべて見る') or contains(., 'Show all')]")
    for button in buttons:
        try:
            driver.execute_script("arguments[0].scrollIntoView({block:'center'});", button)
            time.sleep(0.5)
            button.click()
            time.sleep(1.5)
            return True
        except Exception:
            pass
    return False

def process(url, min_size, max_workers, save_dir, browser_cookies, use_canvas, use_blob, use_screenshot):
    driver = None
    try:
        driver = create_driver()

        if browser_cookies:
            inject_cookies_to_driver(driver, browser_cookies, url)

        driver.get(url)
        wait_for_page_load(driver)
        open_pixiv_all_pages(driver)

        smart_scroll(driver)

        session = requests.Session()
        session.headers.update({**HEADERS, "Referer": PIXIV_REFERER})
        
        if browser_cookies:
            for k, v in browser_cookies.items(): session.cookies.set(k, str(v))
        for c in driver.get_cookies(): session.cookies.set(c['name'], c['value'])

        pixiv_original_urls = []
        print("  [Pixiv] 作品ページを検出。解析を開始します...")
        illust_id = extract_illust_id(url)
        if illust_id:
            pixiv_original_urls = pixiv_fetch_via_api(illust_id, session)
            if pixiv_original_urls:
                print(f"  [Pixiv] APIより {len(pixiv_original_urls)} 枚のオリジナルURLを取得しました。")

        domain = re.sub(r'[\\/*?:"<>|.]', '_', urlparse(url).netloc)
        folder = os.path.join(save_dir, f"{domain}_{random.randint(100,999)}")
        os.makedirs(folder, exist_ok=True)

        found_urls_ordered = []
        seen = set()
        detail_log = []

        # 1. スクリーンショット方式を優先。pixivは遅延読み込みやReferer制限があるため、
        #    ページを完全に表示した後、画像要素を上から順に撮影する。
        screenshot_saved = screenshot_images_top_to_bottom(
            driver,
            min_size,
            folder,
            prefix="image",
            src_keywords=["/img-master/img/", "/img-original/img/", "/img-zip-ugoira/"],
            simple_names=True,
            detail_log=detail_log
        )

        # 2. API結果優先
        for u in pixiv_original_urls:
            if u not in seen:
                found_urls_ordered.append(u)
                seen.add(u)

        # 3. HTML要素からの抽出
        soup = BeautifulSoup(driver.page_source, 'html.parser')
        tags = soup.find_all(['img', 'a'])
        for tag in tags:
            u_list = []
            if tag.name == 'img':
                src = tag.get('src') or tag.get('data-src')
                if src: u_list.append(urljoin(url, src))
            elif tag.name == 'a' and tag.get('href'):
                u_list.append(urljoin(url, tag['href']))

            for u in u_list:
                if not u.startswith('http') or u in seen: continue
                if "i.pximg.net" in u and "master" in u:
                    for cand in pixiv_master_to_original(u):
                        if cand not in seen:
                            found_urls_ordered.append(cand)
                            seen.add(cand)
                else:
                    found_urls_ordered.append(u)
                    seen.add(u)

        # 4. ネットワークログ
        net_urls = collect_network_images(driver)
        for u in net_urls:
            if u not in seen:
                if "i.pximg.net" in u and "master" in u:
                    for cand in pixiv_master_to_original(u):
                        if cand not in seen:
                            found_urls_ordered.append(cand)
                            seen.add(cand)
                else:
                    found_urls_ordered.append(u)
                    seen.add(u)

        # 特殊画像
        extra_saved = 0
        canvas_saved = 0
        blob_saved = 0
        option_screenshot_saved = 0
        if use_canvas:
            canvas_saved = extract_canvas_images(driver, min_size, folder, detail_log)
            extra_saved += canvas_saved
        if use_blob:
            blob_saved = extract_blob_images(driver, min_size, folder, detail_log)
            extra_saved += blob_saved
        if use_screenshot:
            option_screenshot_saved = screenshot_visible_images(driver, min_size, folder, detail_log)
            extra_saved += option_screenshot_saved

        driver.quit(); driver = None

        url_saved = 0
        main_method = "スクリーンショット順次"
        if screenshot_saved == 0:
            print("  [Pixiv] スクリーンショット保存が0枚だったため、URLダウンロードにフォールバックします。")
            url_saved = download_collected_images(found_urls_ordered, session, min_size, max_workers, folder, detail_log)
            main_method = "URL抽出ダウンロード"
        else:
            print("  [Pixiv] スクリーンショット方式で保存済みのため、URLダウンロードはスキップします。")

        method_log = "メイン方式: {} / スクリーンショット順次: {}枚 / URL抽出ダウンロード: {}枚 / Canvas: {}枚 / Blob: {}枚 / 追加Screenshot: {}枚".format(
            main_method, screenshot_saved, url_saved, canvas_saved, blob_saved, option_screenshot_saved
        )
        print(f"  [方式ログ] {method_log}")
        write_extraction_log(folder, [
            f"URL: {url}",
            method_log,
            "保存名: 001_image.png から上から順に連番",
            f"保存枚数合計: {screenshot_saved + url_saved + extra_saved}枚",
            "",
            "詳細:",
            *detail_log,
        ])

        return screenshot_saved + url_saved + extra_saved

    except Exception as e:
        print(f"\n  [エラー] {e}")
        return 0
    finally:
        if driver:
            try: driver.quit()
            except Exception: pass
