import os
import re
import random
import requests
from urllib.parse import urlparse, urljoin
from bs4 import BeautifulSoup
from .common import (
    create_driver, inject_cookies_to_driver, wait_for_page_load, smart_scroll,
    HEADERS, collect_network_images, extract_canvas_images, extract_blob_images,
    screenshot_visible_images, download_collected_images, write_extraction_log
)

def process(url, min_size, max_workers, save_dir, browser_cookies, use_canvas, use_blob, use_screenshot):
    driver = None
    try:
        driver = create_driver()

        if browser_cookies:
            inject_cookies_to_driver(driver, browser_cookies, url)

        driver.get(url)
        wait_for_page_load(driver)
        smart_scroll(driver)

        session = requests.Session()
        session.headers.update({**HEADERS, "Referer": url})
        
        if browser_cookies:
            for k, v in browser_cookies.items(): session.cookies.set(k, str(v))
        for c in driver.get_cookies(): session.cookies.set(c['name'], c['value'])

        domain = re.sub(r'[\\/*?:"<>|.]', '_', urlparse(url).netloc)
        folder = os.path.join(save_dir, f"{domain}_{random.randint(100,999)}")
        os.makedirs(folder, exist_ok=True)

        found_urls_ordered = []
        seen = set()
        detail_log = []

        # HTMLからの抽出
        soup = BeautifulSoup(driver.page_source, 'html.parser')
        tags = soup.find_all(['img', 'a'])
        for tag in tags:
            u_list = []
            if tag.name == 'img':
                src = tag.get('src') or tag.get('data-src')
                if src: u_list.append(urljoin(url, src))
            elif tag.name == 'a' and tag.get('href'):
                u_list.append(urljoin(url, tag['href']))

            for u in u_list:
                if not u.startswith('http') or u in seen: continue
                found_urls_ordered.append(u)
                seen.add(u)

        # ネットワークログからの補足
        net_urls = collect_network_images(driver)
        for u in net_urls:
            if u not in seen:
                found_urls_ordered.append(u)
                seen.add(u)

        # 特殊画像
        extra_saved = 0
        canvas_saved = 0
        blob_saved = 0
        screenshot_saved = 0
        if use_canvas:
            canvas_saved = extract_canvas_images(driver, min_size, folder, detail_log)
            extra_saved += canvas_saved
        if use_blob:
            blob_saved = extract_blob_images(driver, min_size, folder, detail_log)
            extra_saved += blob_saved
        if use_screenshot:
            screenshot_saved = screenshot_visible_images(driver, min_size, folder, detail_log)
            extra_saved += screenshot_saved

        driver.quit(); driver = None

        # ダウンロード実行
        url_saved = download_collected_images(found_urls_ordered, session, min_size, max_workers, folder, detail_log)
        method_log = "URL抽出ダウンロード: {}枚 / Canvas: {}枚 / Blob: {}枚 / Screenshot: {}枚".format(
            url_saved, canvas_saved, blob_saved, screenshot_saved
        )
        print(f"  [方式ログ] {method_log}")
        write_extraction_log(folder, [
            f"URL: {url}",
            "メイン方式: URL抽出ダウンロード",
            method_log,
            f"保存枚数合計: {url_saved + extra_saved}枚",
            "",
            "詳細:",
            *detail_log,
        ])

        return url_saved + extra_saved

    except Exception as e:
        print(f"\n  [エラー] {e}")
        return 0
    finally:
        if driver:
            try: driver.quit()
            except Exception: pass
