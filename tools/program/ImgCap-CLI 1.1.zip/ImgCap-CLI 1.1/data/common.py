import os
import sys
import time
import base64
import requests
import re
import json
from io import BytesIO
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup
from PIL import Image
from concurrent.futures import ThreadPoolExecutor, as_completed
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.support.ui import WebDriverWait
from webdriver_manager.chrome import ChromeDriverManager
from tqdm import tqdm

# ============================================================
# 保存ベースディレクトリ判定
# ============================================================
if getattr(sys, 'frozen', False):
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# ============================================================
# ブラウザCookie取得 (browser_cookie3)
# ============================================================
SUPPORTED_BROWSERS = ["Chrome", "Firefox", "Edge", "Brave", "Opera", "Vivaldi", "Firefox(プロファイル指定)", "使わない"]

def load_cookies_from_browser(browser_name: str, domain_filter: str = "", cookie_file: str = None) -> dict:
    try:
        import browser_cookie3
    except ImportError:
        print("  [Cookie] browser_cookie3 が未インストールです。")
        return {}

    try:
        if browser_name.lower() == "firefox_custom" and cookie_file:
            jar = browser_cookie3.firefox(cookie_file=cookie_file, domain_name=domain_filter)
        else:
            loaders = {
                "chrome":  browser_cookie3.chrome,
                "firefox": browser_cookie3.firefox,
                "edge":    browser_cookie3.edge,
                "brave":   browser_cookie3.brave,
                "opera":   browser_cookie3.opera,
                "vivaldi": browser_cookie3.vivaldi,
            }
            loader = loaders.get(browser_name.lower())
            if not loader:
                return {}
            jar = loader(domain_name=domain_filter) if domain_filter else loader()

        result = {c.name: c.value for c in jar}
        print(f"  [Cookie] 取得成功: {len(result)} 件")
        return result
    except Exception as e:
        print(f"  [Cookie] 取得失敗: {e}")
        return {}

def select_browser_interactively() -> tuple[str, dict]:
    print("\n  ─ Cookie取得元のブラウザを選んでください ─")
    for i, b in enumerate(SUPPORTED_BROWSERS, 1):
        print(f"    {i}. {b}")
    
    while True:
        try:
            choice = int(input("  番号 > ").strip())
            if 1 <= choice <= len(SUPPORTED_BROWSERS):
                browser = SUPPORTED_BROWSERS[choice - 1]
                break
        except ValueError:
            pass
        print("  正しい番号を入力してください。")

    if browser == "使わない":
        return "", {}

    domain_hint = input("  取得するドメインを絞る場合は入力（例: pixiv.net、空欄=全部）: ").strip()
    
    if browser == "Firefox(プロファイル指定)":
        print("\n  Firefoxのプロファイルフォルダ内にある 'cookies.sqlite' のパスを入力してください。")
        print("  例: C:\\Users\\名前\\AppData\\Roaming\\Mozilla\\Firefox\\Profiles\\xxxx.default\\cookies.sqlite")
        path = input("  パス > ").strip().replace('"', '')
        return "firefox", load_cookies_from_browser("firefox_custom", domain_hint, cookie_file=path)

    return browser.lower(), load_cookies_from_browser(browser.lower(), domain_hint)

# ============================================================
# Selenium 設定 & 操作
# ============================================================
def create_driver():
    opts = ChromeOptions()
    opts.add_argument('--headless=new')
    opts.add_argument('--window-size=1920,1080')
    opts.add_argument('--log-level=3')
    opts.add_argument('--no-sandbox')
    opts.add_argument('--disable-dev-shm-usage')
    opts.add_argument('--disable-gpu')
    opts.set_capability('goog:loggingPrefs', {'performance': 'ALL'})
    return webdriver.Chrome(
        service=ChromeService(ChromeDriverManager().install()),
        options=opts
    )

def inject_cookies_to_driver(driver, cookies: dict, target_url: str):
    if not cookies: return
    parsed = urlparse(target_url)
    driver.get(f"{parsed.scheme}://{parsed.netloc}")
    time.sleep(1.5)
    ok = 0
    for name, value in cookies.items():
        try:
            driver.add_cookie({'name': name, 'value': str(value)})
            ok += 1
        except Exception:
            pass
    print(f"  [Cookie注入] {ok}/{len(cookies)} 件をドライバーに設定")

def wait_for_page_load(driver, timeout=20):
    try:
        WebDriverWait(driver, timeout).until(
            lambda d: d.execute_script("return document.readyState") == "complete"
        )
    except Exception:
        pass
    time.sleep(1.5)

def smart_scroll(driver, pause=1.2, max_scrolls=30):
    def one_pass():
        step, pos = 600, 0
        for _ in range(max_scrolls):
            pos += step
            driver.execute_script(f"window.scrollTo(0, {pos});")
            time.sleep(0.3)
            new_h = driver.execute_script("return document.body.scrollHeight")
            if pos >= new_h:
                driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                time.sleep(pause)
                if driver.execute_script("return document.body.scrollHeight") == new_h:
                    break
    one_pass()
    driver.execute_script("window.scrollTo(0, 0);")
    time.sleep(0.5)
    one_pass()
    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
    time.sleep(pause)

# ============================================================
# 特殊画像収集 (Canvas / Blob / Screenshot)
# ============================================================
def extract_canvas_images(driver, min_size: int, save_dir: str, detail_log: list[str] = None) -> int:
    saved = 0
    try:
        canvases = driver.execute_script("""
            const results = [];
            document.querySelectorAll('canvas').forEach((c, i) => {
                try {
                    results.push({
                        index: i, width: c.width, height: c.height,
                        dataUrl: c.toDataURL('image/png')
                    });
                } catch(e) {
                    results.push({index: i, width: c.width, height: c.height, dataUrl: null});
                }
            });
            return results;
        """)
        if not canvases: return 0
        for item in canvases:
            w, h = item.get('width', 0), item.get('height', 0)
            data_url = item.get('dataUrl')
            if not data_url or not data_url.startswith('data:image'): continue
            if w < min_size and h < min_size: continue
            try:
                _, b64 = data_url.split(',', 1)
                img_bytes = base64.b64decode(b64)
                fname = f"canvas_{item['index']}_{w}x{h}.png"
                with open(os.path.join(save_dir, fname), 'wb') as f:
                    f.write(img_bytes)
                print(f"  [Canvas] {fname} ({w}x{h})")
                if detail_log is not None:
                    detail_log.append(f"Canvas: {fname} | size={w}x{h} | index={item['index']}")
                saved += 1
            except Exception as e:
                print(f"  [Canvas] デコード失敗: {e}")
    except Exception as e:
        print(f"  [Canvas] エラー: {e}")
    return saved

def extract_blob_images(driver, min_size: int, save_dir: str, detail_log: list[str] = None) -> int:
    saved = 0
    try:
        blob_urls = driver.execute_script("""
            const urls = new Set();
            document.querySelectorAll('img').forEach(img => {
                if (img.src && img.src.startsWith('blob:')) urls.add(img.src);
                if (img.currentSrc && img.currentSrc.startsWith('blob:')) urls.add(img.currentSrc);
            });
            document.querySelectorAll('[style]').forEach(el => {
                const bg = el.style.backgroundImage;
                const m = bg && bg.match(/url\\(["']?(blob:[^"')]+)["']?\\)/);
                if (m) urls.add(m[1]);
            });
            return Array.from(urls);
        """)
        if not blob_urls: return 0
        print(f"  [Blob] {len(blob_urls)} 件のblob URLを検出")

        for i, blob_url in enumerate(blob_urls):
            try:
                b64 = driver.execute_async_script("""
                    const [url, callback] = arguments;
                    fetch(url)
                        .then(r => r.blob())
                        .then(blob => {
                            const reader = new FileReader();
                            reader.onloadend = () => callback(reader.result);
                            reader.readAsDataURL(blob);
                        })
                        .catch(() => callback(null));
                """, blob_url)

                if not b64 or not b64.startswith('data:image'): continue
                header, enc = b64.split(',', 1)
                img_bytes = base64.b64decode(enc)

                with Image.open(BytesIO(img_bytes)) as im:
                    w, h = im.size
                if w < min_size and h < min_size: continue

                ext_m = re.search(r'data:image/(\w+)', header)
                ext_str = ext_m.group(1) if ext_m else 'png'
                fname = f"blob_{i}_{w}x{h}.{ext_str}"
                with open(os.path.join(save_dir, fname), 'wb') as f:
                    f.write(img_bytes)
                print(f"  [Blob] {fname} ({w}x{h})")
                if detail_log is not None:
                    detail_log.append(f"Blob: {fname} | size={w}x{h} | source={blob_url}")
                saved += 1
            except Exception as e:
                print(f"  [Blob] {blob_url[:50]}... → {e}")
    except Exception as e:
        print(f"  [Blob] エラー: {e}")
    return saved

def screenshot_visible_images(driver, min_size: int, save_dir: str, detail_log: list[str] = None) -> int:
    saved = 0
    try:
        img_elements = driver.find_elements("tag name", "img")
        targets = []
        for el in img_elements:
            try:
                w, h = el.size['width'], el.size['height']
                if w >= min_size or h >= min_size:
                    targets.append((el, w, h))
            except Exception: pass

        if not targets: return 0
        print(f"  [Screenshot] {len(targets)} 件を撮影中...")
        for i, (el, w, h) in enumerate(targets, 1):
            try:
                png = el.screenshot_as_png
                fname = f"screenshot_{i:03d}_{w}x{h}.png"
                with open(os.path.join(save_dir, fname), 'wb') as f:
                    f.write(png)
                if detail_log is not None:
                    src = el.get_attribute("currentSrc") or el.get_attribute("src") or ""
                    detail_log.append(f"Screenshot: {fname} | size={w}x{h} | source={src}")
                saved += 1
            except Exception: pass
        print(f"  [Screenshot] {saved} 枚保存")
    except Exception as e:
        print(f"  [Screenshot] エラー: {e}")
    return saved

def screenshot_images_top_to_bottom(
    driver,
    min_size: int,
    save_dir: str,
    prefix: str = "image",
    src_keywords=None,
    simple_names: bool = True,
    detail_log: list[str] = None
) -> int:
    saved = 0
    try:
        candidates = driver.execute_script("""
            return Array.from(document.querySelectorAll('img')).map((img, i) => {
                if (!img.dataset.imgcapShotId) {
                    img.dataset.imgcapShotId = `imgcap_${Date.now()}_${i}_${Math.random().toString(36).slice(2)}`;
                }
                const r = img.getBoundingClientRect();
                const naturalWidth = img.naturalWidth || 0;
                const naturalHeight = img.naturalHeight || 0;
                return {
                    index: i,
                    shotId: img.dataset.imgcapShotId,
                    src: img.currentSrc || img.src || '',
                    x: r.left + window.scrollX,
                    y: r.top + window.scrollY,
                    width: Math.round(r.width),
                    height: Math.round(r.height),
                    naturalWidth,
                    naturalHeight,
                    visible: r.width > 0 && r.height > 0
                };
            }).filter(item => item.visible);
        """)
        if not candidates:
            return 0

        filtered = []
        seen = set()
        src_keywords = src_keywords or []
        for item in candidates:
            src = item.get("src") or ""
            if src_keywords and not any(keyword in src for keyword in src_keywords):
                continue
            w = max(item.get("width", 0), item.get("naturalWidth", 0))
            h = max(item.get("height", 0), item.get("naturalHeight", 0))
            if w < min_size and h < min_size:
                continue
            key = (src, item.get("index"))
            if key in seen:
                continue
            seen.add(key)
            filtered.append(item)

        filtered.sort(key=lambda item: (item.get("y", 0), item.get("x", 0), item.get("index", 0)))
        if not filtered:
            return 0

        print(f"  [Screenshot順次] {len(filtered)} 件を上から順に撮影中...")
        for order, item in enumerate(filtered, 1):
            try:
                shot_id = item.get("shotId")
                if not shot_id:
                    continue
                matches = driver.find_elements("css selector", f'img[data-imgcap-shot-id="{shot_id}"]')
                if not matches:
                    continue
                el = matches[0]
                driver.execute_script(
                    "arguments[0].scrollIntoView({block:'center', inline:'center'});",
                    el
                )
                time.sleep(1.0)
                try:
                    WebDriverWait(driver, 5).until(
                        lambda d: d.execute_script(
                            "return arguments[0].complete && arguments[0].naturalWidth > 0;",
                            el
                        )
                    )
                except Exception:
                    pass

                size = el.size
                w, h = int(size.get("width", 0)), int(size.get("height", 0))
                if w < min_size and h < min_size:
                    continue

                png = el.screenshot_as_png
                if not png:
                    continue

                if simple_names:
                    fname = f"{order:03d}_{prefix}.png"
                else:
                    fname = f"{prefix}_{order:03d}_{w}x{h}.png"
                path = os.path.join(save_dir, fname)
                n = 2
                while os.path.exists(path):
                    if simple_names:
                        fname = f"{order:03d}_{prefix}_{n}.png"
                    else:
                        fname = f"{prefix}_{order:03d}_{w}x{h}_{n}.png"
                    path = os.path.join(save_dir, fname)
                    n += 1

                with open(path, 'wb') as f:
                    f.write(png)
                if detail_log is not None:
                    src = el.get_attribute("currentSrc") or el.get_attribute("src") or item.get("src") or ""
                    detail_log.append(f"Screenshot順次: {fname} | order={order} | size={w}x{h} | source={src}")
                saved += 1
            except Exception as e:
                print(f"  [Screenshot順次] {order} 件目をスキップ: {e}")

        print(f"  [Screenshot順次] {saved} 枚保存")
    except Exception as e:
        print(f"  [Screenshot順次] エラー: {e}")
    return saved

def write_extraction_log(folder: str, lines: list[str]) -> None:
    try:
        with open(os.path.join(folder, "extraction_log.txt"), "w", encoding="utf-8") as f:
            for line in lines:
                f.write(str(line).rstrip() + "\n")
    except Exception as e:
        print(f"  [方式ログ] ログファイル保存失敗: {e}")

# ============================================================
# 汎用画像取得・ダウンロード
# ============================================================
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
    "Accept-Language": "ja,en;q=0.9",
}

def collect_network_images(driver) -> list[str]:
    found = []
    seen = set()
    try:
        for entry in driver.get_log('performance'):
            try:
                msg = json.loads(entry['message'])['message']
                if msg.get('method') == 'Network.responseReceived':
                    resp = msg['params']['response']
                    if 'image' in resp.get('mimeType',''):
                        u = resp.get('url','')
                        if u.startswith('http') and u not in seen:
                            found.append(u)
                            seen.add(u)
            except Exception: pass
    except Exception: pass
    return found

def fetch_single_image(img_url, session, timeout=10) -> tuple:
    try:
        try:
            head = session.head(img_url, timeout=5, allow_redirects=True)
            ct = head.headers.get('Content-Type','')
            if ct and 'image' not in ct.lower() and 'octet-stream' not in ct.lower():
                return None, f"HEAD:非画像({ct[:30]})"
        except Exception: pass

        res = session.get(img_url, timeout=timeout, allow_redirects=True)
        if res.status_code != 200: return None, f"HTTP{res.status_code}"
        ct = res.headers.get('Content-Type','')
        if ct and 'text' in ct.lower(): return None, "テキストCT"
        data = res.content
        if len(data) < 100: return None, f"データ小({len(data)}B)"
        
        try:
            with Image.open(BytesIO(data)) as im:
                im.verify()
            with Image.open(BytesIO(data)) as im:
                w, h = im.size
                fmt = im.format or 'PNG'
        except Exception as pe:
            return None, f"PIL失敗({pe})"

        path_part = urlparse(res.url).path
        filename = os.path.basename(path_part).split('?')[0] or "image"
        if '.' not in filename:
            filename += '.' + {'PNG':'png','JPEG':'jpg','WEBP':'webp','GIF':'gif'}.get(fmt,'jpg')

        return {'url': img_url, 'final_url': res.url, 'data': data, 'width': w, 'height': h, 'name': filename}, None
    except requests.exceptions.Timeout: return None, "タイムアウト"
    except requests.exceptions.ConnectionError: return None, "接続エラー"
    except Exception as e: return None, f"例外({type(e).__name__})"

def download_collected_images(found_urls_ordered, session, min_size, max_workers, folder, detail_log: list[str] = None):
    max_workers = max(1, int(max_workers or 1))
    results_with_order = []
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        future_to_idx = {ex.submit(fetch_single_image, u, session): i for i, u in enumerate(found_urls_ordered)}
        for f in tqdm(as_completed(future_to_idx), total=len(future_to_idx), desc="  Fetching", leave=False):
            original_idx = future_to_idx[f]
            img, reason = f.result()
            if img and img['width'] >= min_size and img['height'] >= min_size:
                img['original_idx'] = original_idx
                results_with_order.append(img)

    results_with_order.sort(key=lambda x: x['original_idx'])
    url_saved = 0
    used_names = set()
    for i, img in enumerate(results_with_order, 1):
        clean_name = os.path.basename(img['name'])
        filename = f"{i:03d}_{clean_name}"
        stem, ext = os.path.splitext(filename)
        n = 2
        while filename.lower() in used_names or os.path.exists(os.path.join(folder, filename)):
            filename = f"{stem}_{n}{ext}"
            n += 1
        used_names.add(filename.lower())
        path = os.path.join(folder, filename)
        with open(path, 'wb') as f:
            f.write(img['data'])
        if detail_log is not None:
            detail_log.append(
                "URL抽出: {} | size={}x{} | source={} | final={}".format(
                    filename, img["width"], img["height"], img["url"], img["final_url"]
                )
            )
        url_saved += 1

    return url_saved
