import os
import re
import random
import requests
import time
from urllib.parse import urlparse, urljoin
from bs4 import BeautifulSoup
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from .common import (
    create_driver, inject_cookies_to_driver, wait_for_page_load, smart_scroll,
    HEADERS, collect_network_images, extract_canvas_images, extract_blob_images,
    screenshot_visible_images, screenshot_images_top_to_bottom, download_collected_images,
    write_extraction_log
)

RAWLAZY_REFERER = "https://rawlazy.io/"

# ページ中央にある「読み込み」ボタンを探すためのヒューリスティック条件
# （サイトの実際のHTML構造に応じて調整してください）
LOAD_BUTTON_SELECTORS = [
    # よくあるパターンを優先順に列挙
    "button.load-button",
    "button.read-button",
    "button[class*='load']",
    "button[class*='read']",
    "a[class*='load']",
    "a[class*='read']",
    # テキスト内容で探す（XPath）
    "//button[contains(., 'Load')]",
    "//button[contains(., 'Read')]",
    "//button[contains(., '読み込')]",
    "//button[contains(., '読む')]",
    "//a[contains(., 'Load')]",
    "//a[contains(., 'Read')]",
    "//div[@role='button'][contains(., 'Load')]",
    "//div[@role='button'][contains(., 'Read')]",
]

# 画像読み込み完了の待機タイムアウト（秒）
LOAD_WAIT_TIMEOUT = 30
# ボタンクリック後に追加で待機する時間（秒）
POST_CLICK_SLEEP = 3


def is_rawlazy(url: str) -> bool:
    host = (urlparse(url).hostname or "").lower()
    return host == "rawlazy.io" or host.endswith(".rawlazy.io")


def _find_and_click_load_button(driver) -> bool:
    """
    ページ中央付近にある読み込みボタンを探してクリックする。
    成功した場合 True、見つからなかった場合 False を返す。
    """
    vp_height = driver.execute_script("return window.innerHeight")
    vp_width  = driver.execute_script("return window.innerWidth")
    center_x_min = vp_width  * 0.2
    center_x_max = vp_width  * 0.8
    center_y_min = vp_height * 0.2
    center_y_max = vp_height * 0.8

    for selector in LOAD_BUTTON_SELECTORS:
        try:
            if selector.startswith("//"):
                elements = driver.find_elements(By.XPATH, selector)
            else:
                elements = driver.find_elements(By.CSS_SELECTOR, selector)
        except Exception:
            continue

        for elem in elements:
            if not elem.is_displayed():
                continue
            try:
                loc  = elem.location
                size = elem.size
                ex = loc['x'] + size['width']  / 2
                ey = loc['y'] + size['height'] / 2
                # ビューポート座標に変換
                scroll_y = driver.execute_script("return window.scrollY")
                scroll_x = driver.execute_script("return window.scrollX")
                vx = ex - scroll_x
                vy = ey - scroll_y
                if center_x_min <= vx <= center_x_max and center_y_min <= vy <= center_y_max:
                    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", elem)
                    time.sleep(0.5)
                    elem.click()
                    print(f"  [RawLazy] ボタンをクリックしました: '{elem.text.strip()[:40]}' ({selector})")
                    return True
            except Exception:
                continue

    # フォールバック：位置を問わず最初に見つかったボタンをクリック
    for selector in LOAD_BUTTON_SELECTORS:
        try:
            if selector.startswith("//"):
                elements = driver.find_elements(By.XPATH, selector)
            else:
                elements = driver.find_elements(By.CSS_SELECTOR, selector)
        except Exception:
            continue
        for elem in elements:
            if elem.is_displayed():
                try:
                    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", elem)
                    time.sleep(0.5)
                    elem.click()
                    print(f"  [RawLazy] フォールバック: ボタンをクリックしました: '{elem.text.strip()[:40]}'")
                    return True
                except Exception:
                    continue

    return False


def _wait_for_images_to_load(driver, timeout: int = LOAD_WAIT_TIMEOUT) -> int:
    """
    画像読み込み完了を待機する。
    - img 要素の naturalWidth > 0 になるまで待つ
    - タイムアウトした場合は現時点の枚数を返す
    戻り値: 読み込み済み画像枚数
    """
    deadline = time.time() + timeout
    prev_count = -1

    while time.time() < deadline:
        count = driver.execute_script("""
            return Array.from(document.querySelectorAll('img'))
                .filter(img => img.naturalWidth > 0 && img.naturalHeight > 0).length;
        """)
        # 枚数が安定したら完了とみなす
        if count == prev_count and count > 0:
            print(f"  [RawLazy] 画像読み込み完了: {count} 枚")
            return count
        prev_count = count
        time.sleep(1.5)

    count = driver.execute_script("""
        return Array.from(document.querySelectorAll('img'))
            .filter(img => img.naturalWidth > 0).length;
    """)
    print(f"  [RawLazy] タイムアウト。現在の読み込み済み画像: {count} 枚")
    return count


def process(url, min_size, max_workers, save_dir, browser_cookies,
            use_canvas, use_blob, use_screenshot):
    driver = None
    try:
        driver = create_driver()

        # Cookie を注入
        if browser_cookies:
            inject_cookies_to_driver(driver, browser_cookies, url)

        # ページを開く
        driver.get(url)
        wait_for_page_load(driver)

        # ─── ボタンクリック ───────────────────────────────────────
        print("  [RawLazy] 読み込みボタンを探しています...")
        clicked = _find_and_click_load_button(driver)
        if clicked:
            print(f"  [RawLazy] クリック後 {POST_CLICK_SLEEP}s 待機...")
            time.sleep(POST_CLICK_SLEEP)
            # 追加コンテンツの読み込みを待つ
            _wait_for_images_to_load(driver, LOAD_WAIT_TIMEOUT)
        else:
            print("  [RawLazy] 読み込みボタンが見つかりませんでした。そのまま続行します。")

        # スクロールして遅延読み込み画像を展開
        smart_scroll(driver)

        # ─── セッション準備 ──────────────────────────────────────
        session = requests.Session()
        session.headers.update({**HEADERS, "Referer": RAWLAZY_REFERER})
        if browser_cookies:
            for k, v in browser_cookies.items():
                session.cookies.set(k, str(v))
        for c in driver.get_cookies():
            session.cookies.set(c['name'], c['value'])

        # ─── 保存先フォルダ ──────────────────────────────────────
        domain = re.sub(r'[\\/*?:"<>|.]', '_', urlparse(url).netloc)
        folder = os.path.join(save_dir, f"{domain}_{random.randint(100, 999)}")
        os.makedirs(folder, exist_ok=True)

        found_urls_ordered = []
        seen = set()
        detail_log = []

        # ─── 方法 1: スクリーンショット順次取得 ─────────────────
        screenshot_saved = screenshot_images_top_to_bottom(
            driver,
            min_size,
            folder,
            prefix="image",
            simple_names=True,
            detail_log=detail_log
        )

        # ─── 方法 2: HTML要素から URL 抽出 ──────────────────────
        soup = BeautifulSoup(driver.page_source, 'html.parser')
        for tag in soup.find_all(['img', 'a']):
            u_list = []
            if tag.name == 'img':
                src = tag.get('src') or tag.get('data-src') or tag.get('data-lazy-src')
                if src:
                    u_list.append(urljoin(url, src))
            elif tag.name == 'a' and tag.get('href'):
                href = tag['href']
                if re.search(r'\.(jpe?g|png|webp|gif|avif)(\?|$)', href, re.I):
                    u_list.append(urljoin(url, href))

            for u in u_list:
                if u.startswith('http') and u not in seen:
                    found_urls_ordered.append(u)
                    seen.add(u)

        # ─── 方法 3: ネットワークログ ────────────────────────────
        for u in collect_network_images(driver):
            if u not in seen:
                found_urls_ordered.append(u)
                seen.add(u)

        # ─── 特殊画像取得 ────────────────────────────────────────
        extra_saved         = 0
        canvas_saved        = 0
        blob_saved          = 0
        opt_screenshot_saved = 0
        if use_canvas:
            canvas_saved = extract_canvas_images(driver, min_size, folder, detail_log)
            extra_saved += canvas_saved
        if use_blob:
            blob_saved = extract_blob_images(driver, min_size, folder, detail_log)
            extra_saved += blob_saved
        if use_screenshot:
            opt_screenshot_saved = screenshot_visible_images(driver, min_size, folder, detail_log)
            extra_saved += opt_screenshot_saved

        driver.quit()
        driver = None

        # ─── URLダウンロード（スクリーンショットが0枚の場合のみ）─
        url_saved   = 0
        main_method = "スクリーンショット順次"
        if screenshot_saved == 0:
            print("  [RawLazy] スクリーンショット0枚 → URLダウンロードにフォールバックします。")
            url_saved   = download_collected_images(
                found_urls_ordered, session, min_size, max_workers, folder, detail_log
            )
            main_method = "URL抽出ダウンロード"
        else:
            print("  [RawLazy] スクリーンショット方式で保存済み。URLダウンロードはスキップします。")

        # ─── ログ書き出し ────────────────────────────────────────
        total_saved = screenshot_saved + url_saved + extra_saved
        method_log = (
            f"メイン方式: {main_method} / "
            f"スクリーンショット順次: {screenshot_saved}枚 / "
            f"URL抽出ダウンロード: {url_saved}枚 / "
            f"Canvas: {canvas_saved}枚 / "
            f"Blob: {blob_saved}枚 / "
            f"追加Screenshot: {opt_screenshot_saved}枚"
        )
        print(f"  [方式ログ] {method_log}")
        write_extraction_log(folder, [
            f"URL: {url}",
            method_log,
            "保存名: 001_image.png から上から順に連番",
            f"保存枚数合計: {total_saved}枚",
            "",
            "詳細:",
            *detail_log,
        ])

        return total_saved

    except Exception as e:
        import traceback
        print(f"\n  [エラー] {e}")
        traceback.print_exc()
        return 0
    finally:
        if driver:
            try:
                driver.quit()
            except Exception:
                pass