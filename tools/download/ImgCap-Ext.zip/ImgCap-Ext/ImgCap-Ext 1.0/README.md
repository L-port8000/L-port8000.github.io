# ImgCap Chrome Extension

Python CLI 版 [ImgCap-CLI](../imgcap_cli.py) を Chrome 拡張機能に移植したものです。

## 機能

- **現在のタブ**または**URL リスト**から画像を一括抽出
- **Cookie 自動利用** — ログイン済みブラウザのセッションをそのまま使用（外部 Cookie 取得不要）
- **Canvas / Blob / スクリーンショット** 救済オプション
- **サイト別ハンドラ**
  - `pixiv.net` — API + スクリーンショット順次
  - `rawlazy.io` — 読み込みボタンクリック + スクリーンショット
  - その他 — URL 抽出 + ダウンロード

## インストール（開発者モード）

1. Chrome で `chrome://extensions` を開く
2. 右上の **デベロッパーモード** を ON
3. **パッケージ化されていない拡張機能を読み込む**
4. このフォルダ `chrome-extension` を選択

## 使い方

1. 画像を取得したいページを開く（またはポップアップに URL を入力）
2. ツールバーの ImgCap アイコンをクリック
3. 最小サイズ・オプションを設定
4. **抽出開始** をクリック

画像は **ダウンロードフォルダ/ImgCap/日時_ランダム/** 以下に保存されます。

## Python 版との違い

| 項目 | Python CLI | Chrome 拡張 |
|------|------------|-------------|
| Cookie | browser_cookie3 で別ブラウザから取得 | 現在の Chrome セッションを自動使用 |
| 保存先 | `downloaded_images/`（exe 横） | Chrome のダウンロードフォルダ |
| ブラウザ | Selenium ヘッドレス Chrome | 実際に開いているタブ |
| 複数 URL | 対話入力 | ポップアップでカンマ区切り入力 |
| ネットワークログ | Performance ログ（Selenium） | `performance.getEntriesByType('resource')` |

## 注意

- クロスオリジンの画像は Canvas キャプチャが失敗することがあります（Python 版と同様）
- Pixiv 等はログイン済みタブで実行してください
- URL リスト処理時はバックグラウンドタブを自動で開閉します

## ファイル構成

```
chrome-extension/
├── manifest.json
├── background/background.js   # ダウンロード orchestration
├── content/
│   ├── extractor-core.js      # 共通抽出ロジック
│   ├── index.js               # ハンドラ解決・エントリ
│   └── handlers/
│       ├── default.js
│       └── site-handlers.js   # pixiv / rawlazy
├── popup/                     # UI
└── icons/
```
