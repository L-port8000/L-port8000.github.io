/* ======================================================
   background.js
   - パスワード認証(ハッシュ化して chrome.storage.local に保存)
   - セッション管理: 現在開いている正規タブの {sid, tabId} を
     chrome.storage.session に保持(ブラウザ終了で自動消去される一時領域)
   - newtab.html は自分の sid + tabId が一致した場合のみ描画される。
     履歴やブックマークから同じURLを開いても tabId が異なる/セッションが
     消えているため弾かれる。
====================================================== */

const SESSION_KEY = 'authSession'; // { sid, tabId }
const AUTH_KEY = 'authCreds';      // { salt, hash }

/* ---- ハッシュユーティリティ ---- */
async function sha256Hex(str) {
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(str));
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
}
function randomHex(bytes = 16) {
    return Array.from(crypto.getRandomValues(new Uint8Array(bytes))).map(b => b.toString(16).padStart(2, '0')).join('');
}
async function hashPassword(password, salt) {
    return sha256Hex(`${salt}:${password}`);
}

/* ---- 認証情報 ---- */
async function getAuthCreds() {
    const data = await chrome.storage.local.get(AUTH_KEY);
    return data[AUTH_KEY] || null;
}
async function setAuthCreds(password) {
    const salt = randomHex();
    const hash = await hashPassword(password, salt);
    await chrome.storage.local.set({ [AUTH_KEY]: { salt, hash } });
}
async function verifyPassword(password) {
    const creds = await getAuthCreds();
    if (!creds) return false;
    return (await hashPassword(password, creds.salt)) === creds.hash;
}

/* ---- セッション ---- */
async function getSession() {
    const data = await chrome.storage.session.get(SESSION_KEY);
    return data[SESSION_KEY] || null;
}
async function setSession(session) { await chrome.storage.session.set({ [SESSION_KEY]: session }); }
async function clearSession() { await chrome.storage.session.remove(SESSION_KEY); }

async function isSessionActive() {
    const s = await getSession();
    if (!s) return false;
    try { await chrome.tabs.get(s.tabId); return true; }
    catch (e) { await clearSession(); return false; }
}

async function openAuthorizedTab() {
    const sid = crypto.randomUUID();
    const tab = await chrome.tabs.create({ url: `newtab.html?sid=${sid}` });
    await setSession({ sid, tabId: tab.id });
    return tab;
}

/* タブが閉じられたらセッションを無効化 */
chrome.tabs.onRemoved.addListener(async (tabId) => {
    const s = await getSession();
    if (s && s.tabId === tabId) await clearSession();
});

/* ---- popup.html / newtab.html からのメッセージ ---- */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    (async () => {
        switch (msg.type) {
            case 'GET_STATE': {
                const creds = await getAuthCreds();
                const active = await isSessionActive();
                sendResponse({ hasPassword: !!creds, sessionActive: active });
                break;
            }
            case 'SET_INITIAL_PASSWORD': {
                if (await getAuthCreds()) { sendResponse({ ok: false, error: 'already-set' }); break; }
                if (!msg.password || msg.password.length < 4) { sendResponse({ ok: false, error: 'too-short' }); break; }
                await setAuthCreds(msg.password);
                await openAuthorizedTab();
                sendResponse({ ok: true });
                break;
            }
            case 'REQUEST_OPEN': {
                if (await isSessionActive()) { sendResponse({ ok: false, error: 'already-open' }); break; }
                if (!(await verifyPassword(msg.password || ''))) { sendResponse({ ok: false, error: 'wrong-password' }); break; }
                await openAuthorizedTab();
                sendResponse({ ok: true });
                break;
            }
            case 'FOCUS_EXISTING_TAB': {
                const s = await getSession();
                if (!s) { sendResponse({ ok: false }); break; }
                try {
                    const tab = await chrome.tabs.update(s.tabId, { active: true });
                    await chrome.windows.update(tab.windowId, { focused: true });
                    sendResponse({ ok: true });
                } catch (e) { sendResponse({ ok: false }); }
                break;
            }
            case 'CHANGE_PASSWORD': {
                if (!(await verifyPassword(msg.oldPassword || ''))) { sendResponse({ ok: false, error: 'wrong-password' }); break; }
                if (!msg.newPassword || msg.newPassword.length < 4) { sendResponse({ ok: false, error: 'too-short' }); break; }
                await setAuthCreds(msg.newPassword);
                sendResponse({ ok: true });
                break;
            }
            case 'CHECK_SESSION': {
                const s = await getSession();
                const ok = !!(s && s.sid === msg.sid && s.tabId === msg.tabId);
                sendResponse({ ok });
                break;
            }
            default:
                sendResponse({ ok: false, error: 'unknown-message' });
        }
    })();
    return true; // 非同期 sendResponse のためチャンネルを開いたままにする
});
