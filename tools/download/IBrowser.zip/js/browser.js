/* ======================================================
   定数
   ※ 外部プロキシ一覧・埋め込みサイト一覧(旧 PROXIES / DEFAULT_NT_LINKS)は削除済み。
     ニュータブのリンクはユーザーが「編集」ボタンから自由に追加する方式に変更。
====================================================== */
const SANDBOX = "allow-forms allow-modals allow-orientation-lock allow-pointer-lock allow-presentation allow-same-origin allow-scripts allow-storage-access-by-user-activation";
const SPECIAL_URLS = ["settings://", "newtab://"];

/* ======================================================
   プロファイル
====================================================== */
const DEFAULT_SETTINGS = () => ({
    homeUrl: "newtab://",
    darkMode: false,
    bookmarks: [],
    viewMode: "iframe"
});

function loadProfiles() {
    try { return JSON.parse(localStorage.getItem('profiles')) || [{ id: 1, name: "デフォルト" }]; }
    catch(e) { return [{ id: 1, name: "デフォルト" }]; }
}
function saveProfiles() { localStorage.setItem('profiles', JSON.stringify(profiles)); }
function getActiveProfileId() { return parseInt(localStorage.getItem('active-profile-id')) || profiles[0].id; }
function setActiveProfileId(id) { localStorage.setItem('active-profile-id', String(id)); }

let profiles = loadProfiles();
let activeProfileId = getActiveProfileId();
if (!profiles.find(p => p.id === activeProfileId)) { activeProfileId = profiles[0].id; setActiveProfileId(activeProfileId); }

function pk(key) { return `p${activeProfileId}-${key}`; }

let settings = DEFAULT_SETTINGS();
function loadSettings() {
    const saved = localStorage.getItem(pk('settings'));
    settings = saved ? { ...DEFAULT_SETTINGS(), ...JSON.parse(saved) } : DEFAULT_SETTINGS();
}
function saveState() {
    localStorage.setItem(pk('settings'), JSON.stringify(settings));
    localStorage.setItem(pk('sessions'), JSON.stringify(tabs.map(t => ({
        id: t.id, url: t.url, title: t.title, history: t.history, historyIndex: t.historyIndex
    }))));
    localStorage.setItem(pk('last-active'), activeTabId);
}

/* ---- プロファイルモーダル ---- */
function openProfileModal() {
    document.getElementById('profile-name-input').value = '';
    document.getElementById('profile-modal').classList.add('open');
    setTimeout(() => document.getElementById('profile-name-input').focus(), 50);
}
function closeProfileModal() { document.getElementById('profile-modal').classList.remove('open'); }
function confirmCreateProfile() {
    const name = document.getElementById('profile-name-input').value.trim();
    if (!name) return;
    const newId = Date.now();
    profiles.push({ id: newId, name });
    saveProfiles(); closeProfileModal(); switchProfile(newId);
}
document.getElementById('profile-name-input').addEventListener('keydown', e => {
    if (e.key === 'Enter') confirmCreateProfile();
    if (e.key === 'Escape') closeProfileModal();
});

function deleteProfile(id) {
    if (profiles.length <= 1) return;
    if (!confirm(`「${profiles.find(p=>p.id===id)?.name}」を削除しますか？`)) return;
    ['settings','sessions','last-active','nt-links'].forEach(k => localStorage.removeItem(`p${id}-${k}`));
    profiles = profiles.filter(p => p.id !== id);
    saveProfiles();
    if (activeProfileId === id) { activeProfileId = profiles[0].id; setActiveProfileId(activeProfileId); }
    initProfile();
}
function switchProfile(id) {
    if (id === activeProfileId) return;
    tabs.forEach(t => { if(t.element) t.element.remove(); });
    tabs = []; activeTabId = null;
    document.getElementById('view').innerHTML = '';
    activeProfileId = id; setActiveProfileId(id);
    initProfile();
}

/* ======================================================
   ブラウザエンジン
====================================================== */
let tabs = [], activeTabId = null;

function setProgress(p) {
    const bar = document.getElementById('progress-bar');
    bar.style.width = p + "%";
    if (p >= 100) setTimeout(() => { bar.style.width = "0%"; }, 400);
}

function esc(s) {
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function getIconUrl(url) {
    if (url === "settings://") return "icons/settings.png";
    if (url === "newtab://") return "icons/home.png";
    try { return `https://icons.duckduckgo.com/ip3/${new URL(url).hostname}.ico`; }
    catch(e) { return "icons/home.png"; }
}

function getEffectiveUrl(url) {
    // 旧バージョンにあった外部プロキシ経由の埋め込みは廃止。常に指定URLをそのまま使用する。
    return url;
}

/* ---- 特殊URLを開く関数 ---- */
/**
 * openInNewTab(url) — 指定URLを新しいタブで開く (公開API)
 * ニュータブページや設定ページのリンクから呼び出し可能
 */
window.openInNewTab = function(url) {
    createNewTab(url);
};
/** openInNewTabBg(url) — バックグラウンドで新しいタブを作成 */
window.openInNewTabBg = function(url) {
    createTabObject(url);
    renderTabsUI();
    saveState();
};

function createTabObject(url, id = Date.now(), title = "読み込み中...", history = null, hIndex = 0) {
    const tab = { id, url, title, history: history || [url], historyIndex: hIndex, element: null };
    updateTabElement(tab);
    tabs.push(tab);
    return tab;
}

function updateTabElement(tab) {
    if (tab.element) tab.element.remove();
    const viewArea = document.getElementById('view');
    let el;

    if (tab.url === "settings://") {
        el = document.createElement('div');
        el.className = "page-element settings-page";
        renderSettingsInto(el);
    } else if (tab.url === "newtab://") {
        el = document.createElement('div');
        el.className = "page-element newtab-page";
        tab.title = "新しいタブ";
        renderNewtabInto(el);
    } else {
        // Cookie参照について: allow-same-origin を維持しているため、
        // 埋め込んだサイトは通常のタブと同様に自分自身のCookie/ストレージを参照できる。
        const finalUrl = getEffectiveUrl(tab.url);
        if (settings.viewMode === "iframe") {
            el = document.createElement('iframe');
            el.src = finalUrl;
            el.setAttribute("sandbox", SANDBOX);
        } else {
            el = document.createElement(settings.viewMode === "object" ? "object" : "embed");
            el.src = finalUrl; el.data = finalUrl; el.type = "text/html";
        }
        el.className = "page-element";
        setProgress(30);
        el.onload = () => {
            setProgress(100);
            try { tab.title = el.contentDocument.title || new URL(tab.url).hostname; }
            catch(e) { tab.title = tab.url.replace(/https?:\/\//,'').split('/')[0]; }
            renderTabsUI(); updateStarUI();
        };
    }
    el.id = `page-${tab.id}`;
    if (tab.id === activeTabId) el.classList.add('active');
    viewArea.appendChild(el);
    tab.element = el;
}

function switchTab(id) {
    activeTabId = id;
    tabs.forEach(t => {
        const active = t.id === id;
        t.element.classList.toggle('active', active);
        if (active) {
            document.getElementById('url').value = t.url;
            if (t.url === "settings://") renderSettingsInto(t.element);
            if (t.url === "newtab://") renderNewtabInto(t.element);
        }
    });
    updateNavButtons(); updateStarUI(); renderTabsUI(); saveState();
}

function renderTabsUI() {
    const bar = document.getElementById('tabs-bar');
    bar.innerHTML = '';
    tabs.forEach(t => {
        const div = document.createElement('div');
        div.className = `tab ${t.id === activeTabId ? 'active' : ''}`;
        div.innerHTML = `<img src="${getIconUrl(t.url)}"><span class="tab-title">${esc(t.title)}</span><span class="close-btn" data-tid="${t.id}">×</span>`;
        div.querySelector('.close-btn').addEventListener('click', e => { e.stopPropagation(); closeTab(t.id); });
        div.addEventListener('click', () => switchTab(t.id));
        bar.appendChild(div);
    });
    const add = document.createElement('button');
    add.textContent = "+"; add.style = "height:28px; margin-top:5px;";
    add.onclick = () => createNewTab('newtab://');
    bar.appendChild(add);
}

function go() {
    let url = document.getElementById('url').value.trim();
    if (!SPECIAL_URLS.includes(url) && !url.startsWith('http')) url = "https://" + url;
    const tab = tabs.find(t => t.id === activeTabId);
    if (tab.url !== url) {
        tab.history = tab.history.slice(0, tab.historyIndex + 1);
        tab.history.push(url); tab.historyIndex++; tab.url = url;
        updateTabElement(tab); switchTab(tab.id);
    }
}

function navBack() {
    const t = tabs.find(x => x.id === activeTabId);
    if (t && t.historyIndex > 0) { t.historyIndex--; t.url = t.history[t.historyIndex]; updateTabElement(t); switchTab(t.id); }
}
function navForward() {
    const t = tabs.find(x => x.id === activeTabId);
    if (t && t.historyIndex < t.history.length - 1) { t.historyIndex++; t.url = t.history[t.historyIndex]; updateTabElement(t); switchTab(t.id); }
}
function navReload() { const t = tabs.find(x => x.id === activeTabId); if(t) updateTabElement(t); }
function openSettings() { document.getElementById('url').value = "settings://"; go(); }
function goHome() { document.getElementById('url').value = "newtab://"; go(); }
function closeTab(id) {
    if (tabs.length === 1) return;
    const idx = tabs.findIndex(t => t.id === id);
    tabs[idx].element.remove(); tabs.splice(idx, 1);
    switchTab(tabs[Math.max(0, idx - 1)].id);
}
function createNewTab(url = 'newtab://') { switchTab(createTabObject(url).id); }
function updateStarUI() {
    const t = tabs.find(x => x.id === activeTabId);
    const bookmarkable = t && !SPECIAL_URLS.includes(t.url);
    const isB = bookmarkable && settings.bookmarks.some(b => b.url === t.url);
    document.getElementById('star-btn').classList.toggle('active', isB);
}
function updateNavButtons() {
    const t = tabs.find(x => x.id === activeTabId); if (!t) return;
    document.getElementById('btn-back').disabled    = (t.historyIndex <= 0);
    document.getElementById('btn-forward').disabled = (t.historyIndex >= t.history.length - 1);
}
function toggleBookmark() {
    const tab = tabs.find(t => t.id === activeTabId);
    if (!tab || SPECIAL_URLS.includes(tab.url)) return;
    const idx = settings.bookmarks.findIndex(b => b.url === tab.url);
    if (idx > -1) {
        // 既にブックマーク済みなら解除(名前は聞かない)
        settings.bookmarks.splice(idx, 1);
        updateStarUI(); renderBookmarkBar(); saveState();
    } else {
        // 新規追加時は名前を決められるモーダルを開く
        openBookmarkModal(tab.url, tab.title);
    }
}
function renderBookmarkBar() {
    const bar = document.getElementById('bookmark-bar'); bar.innerHTML = '';
    settings.bookmarks.forEach(bm => {
        const div = document.createElement('div'); div.className = 'bm-item';
        div.innerHTML = `<img src="${getIconUrl(bm.url)}"><span>${esc(bm.title)}</span>`;
        div.onclick = () => { document.getElementById('url').value = bm.url; go(); };
        bar.appendChild(div);
    });
}

/* ---- ブックマーク名前設定モーダル (新規追加時 / 既存の名前変更) ---- */
let bookmarkModalState = null; // { mode: 'add', url } または { mode: 'edit', index }

function openBookmarkModal(url, defaultTitle, editIndex = null) {
    bookmarkModalState = (editIndex !== null) ? { mode: 'edit', index: editIndex } : { mode: 'add', url };
    document.getElementById('bookmark-modal-title').textContent = (editIndex !== null) ? 'ブックマーク名を変更' : 'ブックマーク名を設定';
    const input = document.getElementById('bm-title-input');
    input.value = defaultTitle || '';
    document.getElementById('bookmark-modal').classList.add('open');
    setTimeout(() => { input.focus(); input.select(); }, 50);
}
function closeBookmarkModal() {
    document.getElementById('bookmark-modal').classList.remove('open');
    bookmarkModalState = null;
}
function confirmBookmarkModal() {
    if (!bookmarkModalState) { closeBookmarkModal(); return; }
    const name = document.getElementById('bm-title-input').value.trim();
    if (!name) return;

    if (bookmarkModalState.mode === 'add') {
        settings.bookmarks.push({ title: name, url: bookmarkModalState.url });
    } else {
        const bm = settings.bookmarks[bookmarkModalState.index];
        if (bm) bm.title = name;
    }
    saveState();
    updateStarUI(); renderBookmarkBar();
    const settingsPage = document.querySelector('.settings-page');
    if (settingsPage) renderSettingsInto(settingsPage);
    closeBookmarkModal();
}
/* 設定ページのブックマーク一覧の「名前変更」ボタンから呼ばれる */
function renameBookmarkPrompt(index) {
    const bm = settings.bookmarks[index];
    if (!bm) return;
    openBookmarkModal(bm.url, bm.title, index);
}
document.getElementById('bm-title-input').addEventListener('keydown', e => {
    if (e.key === 'Enter') confirmBookmarkModal();
    if (e.key === 'Escape') closeBookmarkModal();
});

/* ======================================================
   ニュータブページ (リンク: ユーザーが自由に編集)
====================================================== */
let ntEditMode = false;
let clockTimer  = null;

function defaultNtLinks() {
    // 起動時の初期状態。カテゴリを1つだけ空で用意し、ユーザーが「編集」から追加していく。
    return [{ id: 1, name: "マイリンク", links: [] }];
}
function loadNtLinks() {
    try {
        const saved = localStorage.getItem(pk('nt-links'));
        return saved ? JSON.parse(saved) : defaultNtLinks();
    } catch(e) { return defaultNtLinks(); }
}
function saveNtLinks(data) {
    localStorage.setItem(pk('nt-links'), JSON.stringify(data));
}

function renderNewtabInto(container) {
    const now = new Date();
    const timeStr = now.toLocaleTimeString('ja-JP', { hour: '2-digit', minute: '2-digit' });
    const dateStr = now.toLocaleDateString('ja-JP', { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' });

    const ntLinks = loadNtLinks();

    let catsHtml = '';
    for (const cat of ntLinks) {
        let linksHtml = '';
        for (const link of cat.links) {
            let hostname = 'example.com';
            try { hostname = new URL(link.url).hostname; } catch(e) {}
            linksHtml += `
            <div class="nt-link" data-action="ntOpen" data-arg0="${cat.id}" data-arg1="${link.id}">
                <img src="https://icons.duckduckgo.com/ip3/${hostname}.ico">
                <span>${esc(link.title)}</span>
                <span class="nt-x" data-action="ntDeleteLink" data-arg0="${cat.id}" data-arg1="${link.id}">×</span>
            </div>`;
        }
        linksHtml += `<div class="nt-add-link" data-action="openLinkModal" data-arg0="${cat.id}">＋ リンク追加</div>`;

        catsHtml += `
        <div class="nt-cat" data-catid="${cat.id}">
            <div class="nt-cat-header">
                <span class="nt-cat-label">${esc(cat.name)}</span>
                <button class="nt-cat-del-btn" data-action="ntDeleteCat" data-arg0="${cat.id}">カテゴリ削除</button>
            </div>
            <div class="nt-links">
                ${linksHtml}
            </div>
        </div>`;
    }

    const emptyHint = ntLinks.length === 0
        ? `<div class="nt-empty-hint">リンクがまだありません。「編集」を押してカテゴリとリンクを追加しましょう。</div>`
        : '';

    container.innerHTML = `
        <div class="nt-header">
            <div class="nt-clock" id="nt-clock">${timeStr}</div>
            <div class="nt-date"  id="nt-date">${dateStr}</div>
        </div>
        <div class="nt-search-row">
            <input id="nt-search" type="text" placeholder="ツールを検索...">
            <button data-action="ntSearch">検索</button>
        </div>
        <div class="nt-body ${ntEditMode ? 'nt-edit-mode' : ''}">
            <div class="nt-top-bar">
                <h3>ツール &amp; リンク</h3>
                <button class="nt-edit-btn ${ntEditMode ? 'on' : ''}" data-action="ntToggleEdit">${ntEditMode ? '完了' : '編集'}</button>
            </div>
            <div class="nt-categories">${catsHtml}</div>
            ${emptyHint}
            <div class="nt-add-cat-row">
                <button data-action="openCatModal">＋ カテゴリ追加</button>
            </div>
        </div>`;

    startClock();

    const si = container.querySelector('#nt-search');
    if (si) {
        si.addEventListener('input', window.ntSearch);
        si.addEventListener('keydown', e => { if (e.key === 'Enter') window.ntSearch(); });
    }
}

function startClock() {
    if (clockTimer) clearInterval(clockTimer);
    clockTimer = setInterval(() => {
        const c = document.getElementById('nt-clock');
        const d = document.getElementById('nt-date');
        if (!c) { clearInterval(clockTimer); clockTimer = null; return; }
        const now = new Date();
        c.textContent = now.toLocaleTimeString('ja-JP', { hour: '2-digit', minute: '2-digit' });
        if (d) d.textContent = now.toLocaleDateString('ja-JP', { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' });
    }, 1000);
}

function rerenderActiveNewtab() {
    const t = tabs.find(x => x.id === activeTabId);
    if (t && t.url === "newtab://") renderNewtabInto(t.element);
}

/* ---- ニュータブ グローバル関数 ---- */
window.ntOpen = function(catId, linkId) {
    const cat  = loadNtLinks().find(c => c.id === catId);
    const link = cat && cat.links.find(l => l.id === linkId);
    if (link) openInNewTab(link.url);
};

window.ntToggleEdit = function() {
    ntEditMode = !ntEditMode;
    rerenderActiveNewtab();
};

window.ntDeleteLink = function(catId, linkId) {
    const data = loadNtLinks();
    const cat = data.find(c => c.id === catId);
    if (!cat) return;
    cat.links = cat.links.filter(l => l.id !== linkId);
    saveNtLinks(data);
    rerenderActiveNewtab();
};

window.ntDeleteCat = function(catId) {
    let data = loadNtLinks();
    const cat = data.find(c => c.id === catId);
    if (!cat) return;
    if (!confirm(`カテゴリ「${cat.name}」を削除しますか？(中のリンクも削除されます)`)) return;
    data = data.filter(c => c.id !== catId);
    saveNtLinks(data);
    rerenderActiveNewtab();
};

/**
 * ツールの検索機能
 * 入力された文字列に基づいてリストのリンクをフィルタリングする
 */
window.ntSearch = function() {
    const input = document.getElementById('nt-search');
    if (!input) return;

    const query = input.value.toLowerCase();
    const categories = document.querySelectorAll('.nt-cat');

    categories.forEach(cat => {
        const links = cat.querySelectorAll('.nt-link');
        let visibleCount = 0;

        links.forEach(link => {
            const titleSpan = link.querySelector('span');
            if (titleSpan) {
                const title = titleSpan.textContent.toLowerCase();
                if (title.includes(query)) {
                    link.style.display = 'flex';
                    visibleCount++;
                } else {
                    link.style.display = 'none';
                }
            }
        });

        cat.style.display = visibleCount > 0 ? 'block' : 'none';
    });
};

/* ---- リンク追加モーダル ---- */
let linkModalCatId = null;
window.openLinkModal = function(catId) {
    linkModalCatId = catId;
    const data = loadNtLinks();
    const sel = document.getElementById('lm-cat');
    sel.innerHTML = data.map(c => `<option value="${c.id}" ${c.id===catId?'selected':''}>${esc(c.name)}</option>`).join('');
    document.getElementById('lm-title').value = '';
    document.getElementById('lm-url').value = '';
    document.getElementById('link-modal').classList.add('open');
    setTimeout(() => document.getElementById('lm-url').focus(), 50);
};
function closeLinkModal() { document.getElementById('link-modal').classList.remove('open'); }
function confirmAddLink() {
    let url = document.getElementById('lm-url').value.trim();
    if (!url) return;
    if (!url.startsWith('http')) url = 'https://' + url;
    let title = document.getElementById('lm-title').value.trim();
    if (!title) { try { title = new URL(url).hostname; } catch(e) { title = url; } }
    const catId = parseInt(document.getElementById('lm-cat').value);

    const data = loadNtLinks();
    const cat = data.find(c => c.id === catId);
    if (!cat) return;
    cat.links.push({ id: Date.now(), title, url });
    saveNtLinks(data);
    closeLinkModal();
    rerenderActiveNewtab();
}

/* ---- カテゴリ追加モーダル ---- */
window.openCatModal = function() {
    document.getElementById('cm-name').value = '';
    document.getElementById('cat-modal').classList.add('open');
    setTimeout(() => document.getElementById('cm-name').focus(), 50);
};
function closeCatModal() { document.getElementById('cat-modal').classList.remove('open'); }
function confirmAddCat() {
    const name = document.getElementById('cm-name').value.trim();
    if (!name) return;
    const data = loadNtLinks();
    data.push({ id: Date.now(), name, links: [] });
    saveNtLinks(data);
    closeCatModal();
    rerenderActiveNewtab();
}
document.getElementById('cm-name').addEventListener('keydown', e => {
    if (e.key === 'Enter') confirmAddCat();
    if (e.key === 'Escape') closeCatModal();
});
document.getElementById('lm-url').addEventListener('keydown', e => {
    if (e.key === 'Enter') confirmAddLink();
    if (e.key === 'Escape') closeLinkModal();
});

/* ======================================================
   設定ページ
====================================================== */
function renderSettingsInto(container) {
    const profileHtml = profiles.map(p => `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
            <span>${p.id === activeProfileId ? '▶ ' : ''}<strong>${esc(p.name)}</strong>${p.id === activeProfileId ? ' (現在)' : ''}</span>
            <div style="display:flex; gap:6px;">
                ${p.id !== activeProfileId ? `<button data-action="switchProfile" data-arg0="${p.id}">切替</button>` : ''}
                ${profiles.length > 1 ? `<button data-action="deleteProfile" data-arg0="${p.id}" style="color:#c00; border-color:#c00;">削除</button>` : ''}
            </div>
        </div>`).join('');

    const bmsHtml = settings.bookmarks.length === 0
        ? '<p style="opacity:0.5">なし</p>'
        : settings.bookmarks.map((b,i) => `
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
            <span><img src="${getIconUrl(b.url)}" style="width:12px; margin-right:5px;">${esc(b.title)}</span>
            <div style="display:flex; gap:6px;">
                <button data-action="renameBookmarkPrompt" data-arg0="${i}">名前変更</button>
                <button data-action="deleteBookmark" data-arg0="${i}">削除</button>
            </div>
          </div>`).join('');

    container.innerHTML = `
        <div class="card"><h3>👤 プロファイル管理</h3>
            ${profileHtml}
            <button data-action="openProfileModal" style="margin-top:8px;">＋ 新規プロファイル</button>
        </div>
        <div class="card"><h3>★ ブックマーク</h3>${bmsHtml}</div>
        <div class="card"><h3>🌓 表示・モード</h3>
            <button data-action="toggleDarkMode">ダークモード切替</button>
            <div style="margin-top:10px;">
                表示方式:
                <select data-action="changeViewMode" style="margin-left:10px;">
                    <option value="iframe"  ${settings.viewMode==='iframe' ?'selected':''}>iframe (通常)</option>
                    <option value="embed"   ${settings.viewMode==='embed'  ?'selected':''}>embed (代替表示)</option>
                    <option value="object"  ${settings.viewMode==='object' ?'selected':''}>object</option>
                </select>
            </div>
        </div>`;
}

function deleteBookmark(index) {
    settings.bookmarks.splice(index, 1);
    saveState();
    renderSettingsInto(document.querySelector('.settings-page'));
    renderBookmarkBar();
}

function toggleDarkMode() {
    settings.darkMode = !settings.darkMode;
    document.body.classList.toggle('dark-mode');
    saveState();
    renderSettingsInto(document.querySelector('.settings-page'));
}

/* ======================================================
   表示モード / 全画面
====================================================== */
function toggleViewMode() {
    settings.viewMode = settings.viewMode === "iframe" ? "embed" : "iframe";
    updateViewModeButton(); saveState();
    const t = tabs.find(x => x.id === activeTabId);
    if (t && !SPECIAL_URLS.includes(t.url)) updateTabElement(t);
}
/* 設定ページの <select> の change イベントから呼ばれる (iframe/embed/objectを直接指定) */
function changeViewMode(value) {
    settings.viewMode = value;
    updateViewModeButton(); saveState();
    const t = tabs.find(x => x.id === activeTabId);
    if (t && !SPECIAL_URLS.includes(t.url)) updateTabElement(t);
}
function updateViewModeButton() {
    const btn = document.getElementById('view-mode-btn');
    if (settings.viewMode === "embed") {
        btn.classList.add('embed-mode'); btn.title = "embedモード (代替表示)";
    } else {
        btn.classList.remove('embed-mode'); btn.title = "iframeモード (通常)";
    }
}
function toggleFullscreen() {
    if (!document.fullscreenElement) document.documentElement.requestFullscreen().catch(e=>console.error(e));
    else exitFullscreen();
}
function exitFullscreen() { if (document.exitFullscreen) document.exitFullscreen(); }

/* ======================================================
   初期化
====================================================== */
function initProfile() {
    loadSettings();
    document.body.classList.toggle('dark-mode', !!settings.darkMode);
    updateViewModeButton();
    ntEditMode = false;

    const savedTabs = localStorage.getItem(pk('sessions'));
    if (savedTabs) {
        JSON.parse(savedTabs).forEach(t => createTabObject(t.url, t.id, t.title, t.history, t.historyIndex));
        const lastActive = parseInt(localStorage.getItem(pk('last-active')));
        switchTab((tabs.find(t => t.id === lastActive) || tabs[0]).id);
    } else {
        createNewTab('newtab://');
    }
    renderBookmarkBar();
}

/* アクセス拒否画面の「このタブを閉じる」ボタンから呼ばれる */
function closeThisTab() { window.close(); }

/* ======================================================
   イベント委譲ディスパッチャ
   拡張機能ページのCSP(script-src 'self')はHTML内の onclick="..." のような
   インラインハンドラを一切許可しないため、テンプレート文字列側には
   data-action="関数名" data-arg0="値" data-arg1="値" ... を付けておき、
   ここで一括してクリック/change/画像読み込みエラーを処理する。
====================================================== */
function collectDataArgs(el) {
    const args = [];
    let i = 0;
    while (el.dataset[`arg${i}`] !== undefined) {
        let v = el.dataset[`arg${i}`];
        if (/^-?\d+$/.test(v)) v = parseInt(v, 10);
        args.push(v);
        i++;
    }
    return args;
}
function dispatchAction(el, extraArg) {
    const action = el.dataset.action;
    if (!action || typeof window[action] !== 'function') return;
    const args = collectDataArgs(el);
    if (extraArg !== undefined) args.push(extraArg);
    window[action](...args);
}
document.addEventListener('click', e => {
    const el = e.target.closest('[data-action]');
    if (!el || el.tagName === 'SELECT') return;
    e.preventDefault();
    dispatchAction(el);
});
document.addEventListener('change', e => {
    const el = e.target.closest('[data-action]');
    if (el && el.tagName === 'SELECT') dispatchAction(el, el.value);
});
/* favicon読み込み失敗時は非表示に (error イベントはバブリングしないためキャプチャ段階で拾う) */
document.addEventListener('error', e => {
    if (e.target && e.target.tagName === 'IMG') e.target.style.display = 'none';
}, true);

/* セッション検証(guard.js)を通過してから呼び出される起動関数 */
window.startApp = function() {
    document.getElementById("url").addEventListener("keydown", e => { if (e.key === "Enter") go(); });
    initProfile();
};
