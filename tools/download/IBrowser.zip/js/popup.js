const app = document.getElementById('app');

/* Service Workerが起眠から起きるまでの一瞬など、"Could not establish
   connection" になった場合は少し待って自動リトライする */
async function sendMsg(msg, retries = 4) {
    for (let i = 0; i < retries; i++) {
        try {
            return await chrome.runtime.sendMessage(msg);
        } catch (e) {
            if (i === retries - 1) throw e;
            await new Promise(r => setTimeout(r, 100 * (i + 1)));
        }
    }
}

async function init() {
    try {
        const state = await sendMsg({ type: 'GET_STATE' });
        if (!state.hasPassword) {
            renderSetup();
        } else if (state.sessionActive) {
            renderChangePassword();
        } else {
            renderLogin();
        }
    } catch (e) {
        renderConnectionError();
    }
}

function renderConnectionError() {
    app.innerHTML = `
        <h2>⚠️ 接続エラー</h2>
        <p class="desc">拡張機能の起動処理に接続できませんでした。拡張機能を再読み込みした直後は起こることがあります。</p>
        <button id="retry-btn">再試行</button>
    `;
    document.getElementById('retry-btn').onclick = () => { app.innerHTML = '読み込み中...'; init(); };
}

/* ============ 初回パスワード設定 ============ */
function renderSetup() {
    app.innerHTML = `
        <h2>🔑 初期パスワード設定</h2>
        <p class="desc">まだパスワードが設定されていません。次回以降このパスワードでブラウザを開きます。</p>
        <label>パスワード (4文字以上)</label>
        <input type="password" id="pw1" autocomplete="new-password">
        <label>確認用</label>
        <input type="password" id="pw2" autocomplete="new-password">
        <button id="submit-btn">設定して開く</button>
        <p id="error"></p>
    `;
    const submit = async () => {
        const pw1 = document.getElementById('pw1').value;
        const pw2 = document.getElementById('pw2').value;
        const err = document.getElementById('error');
        if (pw1.length < 4) { err.textContent = 'パスワードは4文字以上にしてください'; return; }
        if (pw1 !== pw2) { err.textContent = '確認用パスワードが一致しません'; return; }
        try {
            const res = await sendMsg({ type: 'SET_INITIAL_PASSWORD', password: pw1 });
            if (res.ok) { window.close(); }
            else { err.textContent = '設定に失敗しました'; }
        } catch (e) {
            err.textContent = '拡張機能との通信に失敗しました。もう一度お試しください';
        }
    };
    document.getElementById('submit-btn').onclick = submit;
    document.getElementById('pw2').addEventListener('keydown', e => { if (e.key === 'Enter') submit(); });
    document.getElementById('pw1').focus();
}

/* ============ ログイン(開く) ============ */
function renderLogin() {
    app.innerHTML = `
        <h2>🔒 パスワードを入力</h2>
        <p class="desc">ブラウザを開くにはパスワードが必要です。</p>
        <label>パスワード</label>
        <input type="password" id="pw" autocomplete="current-password">
        <button id="open-btn">開く</button>
        <p id="error"></p>
    `;
    const submit = async () => {
        const pw = document.getElementById('pw').value;
        const err = document.getElementById('error');
        try {
            const res = await sendMsg({ type: 'REQUEST_OPEN', password: pw });
            if (res.ok) { window.close(); }
            else if (res.error === 'already-open') { renderChangePassword(); }
            else { err.textContent = 'パスワードが違います'; document.getElementById('pw').value = ''; document.getElementById('pw').focus(); }
        } catch (e) {
            err.textContent = '拡張機能との通信に失敗しました。もう一度お試しください';
        }
    };
    document.getElementById('open-btn').onclick = submit;
    document.getElementById('pw').addEventListener('keydown', e => { if (e.key === 'Enter') submit(); });
    document.getElementById('pw').focus();
}

/* ============ 既に開いている場合 → パスワード変更画面 ============ */
function renderChangePassword() {
    app.innerHTML = `
        <span class="badge">● 起動中</span>
        <h2>🔐 パスワード変更</h2>
        <p class="desc">ブラウザは既に別タブで開いています。ここではパスワードの変更のみ行えます。</p>
        <button class="secondary" id="focus-btn">開いているタブに切り替える</button>
        <div class="divider"></div>
        <label>現在のパスワード</label>
        <input type="password" id="old-pw" autocomplete="current-password">
        <label>新しいパスワード (4文字以上)</label>
        <input type="password" id="new-pw1" autocomplete="new-password">
        <label>新しいパスワード (確認用)</label>
        <input type="password" id="new-pw2" autocomplete="new-password">
        <button id="change-btn" class="danger-area">パスワードを変更</button>
        <p id="error"></p>
        <p id="ok-msg"></p>
    `;
    document.getElementById('focus-btn').onclick = async () => {
        try {
            await sendMsg({ type: 'FOCUS_EXISTING_TAB' });
            window.close();
        } catch (e) {
            document.getElementById('error').textContent = '拡張機能との通信に失敗しました。もう一度お試しください';
        }
    };
    const submit = async () => {
        const oldPw = document.getElementById('old-pw').value;
        const newPw1 = document.getElementById('new-pw1').value;
        const newPw2 = document.getElementById('new-pw2').value;
        const err = document.getElementById('error');
        const ok = document.getElementById('ok-msg');
        err.textContent = ''; ok.textContent = '';
        if (newPw1.length < 4) { err.textContent = '新しいパスワードは4文字以上にしてください'; return; }
        if (newPw1 !== newPw2) { err.textContent = '確認用パスワードが一致しません'; return; }
        try {
            const res = await sendMsg({ type: 'CHANGE_PASSWORD', oldPassword: oldPw, newPassword: newPw1 });
            if (res.ok) {
                ok.textContent = '変更しました';
                document.getElementById('old-pw').value = '';
                document.getElementById('new-pw1').value = '';
                document.getElementById('new-pw2').value = '';
            } else if (res.error === 'wrong-password') {
                err.textContent = '現在のパスワードが違います';
            } else {
                err.textContent = '変更に失敗しました';
            }
        } catch (e) {
            err.textContent = '拡張機能との通信に失敗しました。もう一度お試しください';
        }
    };
    document.getElementById('change-btn').onclick = submit;
    document.getElementById('new-pw2').addEventListener('keydown', e => { if (e.key === 'Enter') submit(); });
    document.getElementById('old-pw').focus();
}

init();
