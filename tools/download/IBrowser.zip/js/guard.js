/* ======================================================
   guard.js
   このタブが background.js によって正規に発行されたタブかどうかを
   URLの sid とこのタブ自身の tabId で検証する。
   一致しなければアプリ本体(startApp)は一切呼び出さず、
   アクセス拒否画面のみ表示する。
====================================================== */
(async () => {
    try {
        const sid = new URLSearchParams(location.search).get('sid') || '';
        const tab = await chrome.tabs.getCurrent();
        const tabId = tab ? tab.id : null;

        let res = null;
        for (let i = 0; i < 4; i++) {
            try {
                res = await chrome.runtime.sendMessage({ type: 'CHECK_SESSION', sid, tabId });
                break;
            } catch (e) {
                if (i === 3) throw e;
                await new Promise(r => setTimeout(r, 100 * (i + 1)));
            }
        }

        if (res && res.ok) {
            document.body.style.visibility = 'visible';
            window.startApp();
        } else {
            denyAccess();
        }
    } catch (e) {
        denyAccess();
    }
})();

function denyAccess() {
    document.getElementById('access-denied').style.display = 'flex';
    document.body.style.visibility = 'visible';
}
