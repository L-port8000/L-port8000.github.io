@echo off
cd /d "%~dp0"

py -3 apk_from_html.py
if %errorlevel%==9009 python apk_from_html.py

echo.
pause
