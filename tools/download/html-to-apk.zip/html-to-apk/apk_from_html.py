#!/usr/bin/env python3
"""
Build a simple Android APK that displays embedded HTML in a WebView.

Prerequisites:
  - Android SDK installed, normally by Android Studio
  - Gradle installed, cached by Android Studio/Gradle Wrapper, or pass --gradle
  - Network access the first time Gradle downloads the Android Gradle Plugin

Examples:
  python apk_from_html.py index.html --name "My HTML App" --package com.example.myhtml
  python apk_from_html.py site.zip --name "My ZIP App" --package com.example.zipapp
  python apk_from_html.py site.zip --icon icon.png
  echo "<h1>Hello</h1>" | python apk_from_html.py --stdin --name HelloHtml
  python apk_from_html.py
  python apk_from_html.py index.html --no-build
"""

from __future__ import annotations

import argparse
import html as html_lib
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path


DEFAULT_AGP_VERSION = "8.2.0"
DEFAULT_COMPILE_SDK = 35
DEFAULT_MIN_SDK = 23

PACKAGE_RE = re.compile(
    r"^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)+$"
)
DEFAULT_OUT_DIR = "html_apk_project"


MAIN_ACTIVITY_TEMPLATE = """package {package_name};

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {{
    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {{
        super.onCreate(savedInstanceState);

        WebView webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);

        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }}
}}
"""


MANIFEST_TEMPLATE = """<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET" />

    <application
        android:allowBackup="true"
        android:usesCleartextTraffic="true"
        android:theme="@style/AppTheme"
        android:label="{app_name}"{icon_attributes}>
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
"""


ROOT_BUILD_GRADLE_TEMPLATE = """plugins {{
    id 'com.android.application' version '{agp_version}' apply false
}}
"""


SETTINGS_GRADLE = """pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = 'HtmlWebViewApk'
include ':app'
"""


APP_BUILD_GRADLE_TEMPLATE = """plugins {{
    id 'com.android.application'
}}

android {{
    namespace '{package_name}'
    compileSdk {compile_sdk}

    defaultConfig {{
        applicationId '{package_name}'
        minSdk {min_sdk}
        targetSdk {compile_sdk}
        versionCode {version_code}
        versionName '{version_name}'
    }}
}}
"""


GRADLE_PROPERTIES = """android.suppressUnsupportedCompileSdk=35
org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
"""


STYLES_XML = """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="AppTheme" parent="android:style/Theme.Material.Light.NoActionBar">
        <item name="android:windowActionBar">false</item>
        <item name="android:windowNoTitle">true</item>
        <item name="android:windowLightStatusBar">true</item>
        <item name="android:colorAccent">#222222</item>
    </style>
</resources>
"""


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Create an Android APK that embeds and displays HTML."
    )
    parser.add_argument(
        "html",
        nargs="?",
        help="Path to an HTML file, folder, or ZIP file. Omit when using --stdin.",
    )
    parser.add_argument(
        "--stdin",
        action="store_true",
        help="Read HTML from standard input instead of a file.",
    )
    parser.add_argument(
        "--name",
        default="HTML App",
        help="Application label shown on Android.",
    )
    parser.add_argument(
        "--package",
        default="com.example.htmlapp",
        help="Android application ID, for example com.example.htmlapp.",
    )
    parser.add_argument(
        "--out",
        default=DEFAULT_OUT_DIR,
        help="Directory where the Android project will be generated.",
    )
    parser.add_argument(
        "--apk",
        default="",
        help="Optional path to copy the built debug APK to.",
    )
    parser.add_argument(
        "--entry",
        default="",
        help="Entry HTML file inside a folder/ZIP. Defaults to index.html.",
    )
    parser.add_argument(
        "--icon",
        default="",
        help="Optional launcher icon image path. Supports png, jpg/jpeg, or webp.",
    )
    parser.add_argument("--version-code", type=int, default=1)
    parser.add_argument("--version-name", default="1.0")
    parser.add_argument("--compile-sdk", type=int, default=DEFAULT_COMPILE_SDK)
    parser.add_argument("--min-sdk", type=int, default=DEFAULT_MIN_SDK)
    parser.add_argument("--agp-version", default=DEFAULT_AGP_VERSION)
    parser.add_argument(
        "--gradle",
        default="",
        help="Gradle executable path. Defaults to gradle/gradle.bat on PATH.",
    )
    parser.add_argument(
        "--java-home",
        default="",
        help="JAVA_HOME path. Auto-detected from Android Studio when omitted.",
    )
    parser.add_argument(
        "--android-sdk",
        default="",
        help="Android SDK path. Auto-detected when omitted.",
    )
    parser.add_argument(
        "--clean",
        action="store_true",
        help="Delete the output project directory before generating files.",
    )
    parser.add_argument(
        "--no-build",
        action="store_true",
        help="Only generate the Android project; do not run Gradle.",
    )
    return parser.parse_args()


def prompt(default: str, label: str) -> str:
    suffix = f" [{default}]" if default else ""
    value = input(f"{label}{suffix}: ").strip()
    return value or default


def read_multiline_html() -> str:
    print("HTMLを貼り付けてください。最後の行に EOF と入力すると終了します。")
    lines: list[str] = []
    while True:
        try:
            line = input()
        except EOFError:
            break
        if line.strip() == "EOF":
            break
        lines.append(line)
    html = "\n".join(lines)
    if not html.strip():
        raise SystemExit("HTMLが入力されていません。")
    return html


def read_config(path: str) -> list[str]:
    lines = Path(path.strip('"')).expanduser().read_text(encoding="utf-8").splitlines()
    return [line.strip() for line in lines]


def interactive_args() -> tuple[argparse.Namespace, str | Path]:
    print("HTMLからAndroid APKを作成します。")
    print("HTMLファイル、HTMLフォルダ、ZIPファイルに対応しています。")
    print()

    cfg_path = prompt("", "設定ファイルのパス（不要なら空欄）")
    cfg: list[str] = []
    if cfg_path:
        cfg = read_config(cfg_path)

    def val(index: int, default: str = "") -> str:
        return cfg[index] if index < len(cfg) and cfg[index] else default

    if cfg and cfg[0]:
        source = cfg[0]
        if source.lower() == "paste":
            source_value: str | Path = read_multiline_html()
        else:
            source_path = Path(source.strip('"')).expanduser()
            if not source_path.exists():
                raise SystemExit(f"ファイルまたはフォルダが見つかりません: {source_path}")
            source_value = source_path

        app_name = val(1) or "HTML App"
        package_name = val(2) or "com.example.htmlapp"
        out_dir = val(3) or DEFAULT_OUT_DIR
        apk_path = val(4) or f"{app_name.replace(' ', '_')}.apk"
        icon_path = val(5) or ""

        args = argparse.Namespace(
            html=None,
            stdin=False,
            name=app_name,
            package=package_name,
            out=out_dir,
            apk=apk_path,
            entry="",
            icon=icon_path,
            version_code=1,
            version_name="1.0",
            compile_sdk=DEFAULT_COMPILE_SDK,
            min_sdk=DEFAULT_MIN_SDK,
            agp_version=DEFAULT_AGP_VERSION,
            gradle="",
            java_home="",
            android_sdk="",
            clean=False,
            no_build=False,
        )
        return args, source_value

    source = prompt("", "HTML/フォルダ/ZIPのパス。貼り付ける場合は PASTE")
    if source.lower() == "paste":
        source_value: str | Path = read_multiline_html()
    else:
        source_path = Path(source.strip('"')).expanduser()
        if not source_path.exists():
            raise SystemExit(f"ファイルまたはフォルダが見つかりません: {source_path}")
        source_value = source_path

    app_name = prompt("HTML App", "アプリ名")
    package_name = prompt("com.example.htmlapp", "パッケージ名")
    out_dir = prompt(DEFAULT_OUT_DIR, "出力プロジェクトフォルダ")
    apk_path = prompt(f"{app_name.replace(' ', '_')}.apk", "APK出力先")
    icon_path = prompt("", "アイコン画像のパス。不要なら空欄")
    build_answer = prompt("y", "APKまでビルドしますか？ y/n").lower()

    args = argparse.Namespace(
        html=None,
        stdin=False,
        name=app_name,
        package=package_name,
        out=out_dir,
        apk=apk_path,
        entry="",
        icon=icon_path,
        version_code=1,
        version_name="1.0",
        compile_sdk=DEFAULT_COMPILE_SDK,
        min_sdk=DEFAULT_MIN_SDK,
        agp_version=DEFAULT_AGP_VERSION,
        gradle="",
        java_home="",
        android_sdk="",
        clean=False,
        no_build=build_answer not in {"y", "yes"},
    )
    return args, source_value


def read_source(args: argparse.Namespace) -> str | Path:
    if args.stdin:
        data = sys.stdin.read()
        if not data.strip():
            raise SystemExit("No HTML was provided on standard input.")
        return data

    if not args.html:
        raise SystemExit("Provide an HTML file/folder/ZIP path, or use --stdin.")

    source_path = Path(args.html).expanduser()
    if not source_path.exists():
        raise SystemExit(f"Source not found: {source_path}")
    return source_path


def ensure_safe_package_name(package_name: str) -> None:
    if not PACKAGE_RE.match(package_name):
        raise SystemExit(
            "Invalid package name. Use a Java-style ID such as "
            "com.example.myhtml."
        )


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8", newline="\n")


def copy_tree_contents(source: Path, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    for item in source.iterdir():
        target = destination / item.name
        if item.is_dir():
            shutil.copytree(item, target, dirs_exist_ok=True)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item, target)


def is_within_directory(base: Path, candidate: Path) -> bool:
    try:
        candidate.resolve().relative_to(base.resolve())
        return True
    except ValueError:
        return False


def safe_extract_zip(zip_path: Path, destination: Path) -> None:
    with zipfile.ZipFile(zip_path) as archive:
        for member in archive.infolist():
            target = destination / member.filename
            if not is_within_directory(destination, target):
                raise SystemExit(f"Unsafe ZIP entry skipped: {member.filename}")
        archive.extractall(destination)


def find_entry_file(root: Path, requested_entry: str = "") -> Path:
    if requested_entry:
        entry = root / requested_entry
        if not entry.is_file():
            raise SystemExit(f"Entry HTML was not found: {entry}")
        return entry

    direct_index = root / "index.html"
    if direct_index.is_file():
        return direct_index

    indexes = sorted(root.rglob("index.html"))
    if indexes:
        return indexes[0]

    html_files = sorted(list(root.rglob("*.html")) + list(root.rglob("*.htm")))
    if len(html_files) == 1:
        return html_files[0]
    if not html_files:
        raise SystemExit("No HTML file was found in the folder/ZIP.")
    raise SystemExit("Multiple HTML files found. Pass --entry path/to/index.html.")


def prepare_assets(source: str | Path, assets_dir: Path, entry_name: str = "") -> None:
    if isinstance(source, str):
        write_text(assets_dir / "index.html", source)
        return

    source = source.resolve()
    if source.is_file() and source.suffix.lower() in {".html", ".htm"}:
        write_text(assets_dir / "index.html", source.read_text(encoding="utf-8"))
        return

    with tempfile.TemporaryDirectory() as tmp:
        if source.is_file() and source.suffix.lower() == ".zip":
            source_root = Path(tmp) / "unzipped"
            source_root.mkdir(parents=True)
            safe_extract_zip(source, source_root)
        elif source.is_dir():
            source_root = source
        else:
            raise SystemExit("Source must be an HTML file, folder, ZIP, or --stdin HTML.")

        entry = find_entry_file(source_root, entry_name)
        app_root = entry.parent
        copy_tree_contents(app_root, assets_dir)
        if entry.name.lower() != "index.html":
            shutil.copy2(entry, assets_dir / "index.html")


def prepare_icon(icon_path: str, project_dir: Path) -> str:
    if not icon_path:
        return ""

    source = Path(icon_path.strip('"')).expanduser()
    if not source.is_file():
        raise SystemExit(f"Icon file was not found: {source}")

    suffix = source.suffix.lower()
    if suffix not in {".png", ".jpg", ".jpeg", ".webp"}:
        raise SystemExit("Icon must be a png, jpg/jpeg, or webp image.")

    extension = ".jpg" if suffix == ".jpeg" else suffix

    mipmap_dir = project_dir / "app" / "src" / "main" / "res" / "mipmap-nodpi"
    drawable_dir = project_dir / "app" / "src" / "main" / "res" / "drawable"
    anydpi_v26_dir = (
        project_dir / "app" / "src" / "main" / "res" / "mipmap-anydpi-v26"
    )

    # Remove previous icon files to avoid duplicate-resource conflicts
    for d in (mipmap_dir, drawable_dir, anydpi_v26_dir):
        if d.is_dir():
            for f in d.iterdir():
                if f.stem in {"app_icon", "app_icon_layer"}:
                    f.unlink()

    # Legacy icon for API 25 and below
    mipmap_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, mipmap_dir / f"app_icon{extension}")

    # Layer image referenced by the adaptive icon XML (separate name
    # prevents circular resource resolution on API 26+)
    drawable_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, drawable_dir / f"app_icon_layer{extension}")

    # Explicit adaptive-icon definition for Android 8+ (API 26+)
    # Both layers use the same image so it fills the full 108dp viewport
    # without any solid-color background causing a border
    anydpi_v26_dir.mkdir(parents=True, exist_ok=True)
    adaptive_icon_xml = f"""<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/app_icon_layer"/>
    <foreground android:drawable="@drawable/app_icon_layer"/>
</adaptive-icon>
"""
    (anydpi_v26_dir / "app_icon.xml").write_text(
        adaptive_icon_xml, encoding="utf-8"
    )

    return (
        '\n        android:icon="@mipmap/app_icon"'
        '\n        android:roundIcon="@mipmap/app_icon"'
    )


def gradle_single_quote(value: str) -> str:
    return value.replace("\\", "\\\\").replace("'", "\\'")


def generate_project(args: argparse.Namespace, source: str | Path) -> Path:
    project_dir = Path(args.out).resolve()
    if args.clean and project_dir.exists():
        shutil.rmtree(project_dir)

    java_dir = (
        project_dir
        / "app"
        / "src"
        / "main"
        / "java"
        / Path(*args.package.split("."))
    )

    write_text(
        project_dir / "settings.gradle",
        SETTINGS_GRADLE,
    )
    write_text(
        project_dir / "build.gradle",
        ROOT_BUILD_GRADLE_TEMPLATE.format(agp_version=args.agp_version),
    )
    write_text(
        project_dir / "app" / "build.gradle",
        APP_BUILD_GRADLE_TEMPLATE.format(
            package_name=args.package,
            compile_sdk=args.compile_sdk,
            min_sdk=args.min_sdk,
            version_code=args.version_code,
            version_name=gradle_single_quote(args.version_name),
        ),
    )
    write_text(project_dir / "gradle.properties", GRADLE_PROPERTIES)
    write_text(
        project_dir / "app" / "src" / "main" / "AndroidManifest.xml",
        MANIFEST_TEMPLATE.format(
            app_name=html_lib.escape(args.name, quote=True),
            icon_attributes=prepare_icon(args.icon, project_dir),
        ),
    )
    write_text(
        java_dir / "MainActivity.java",
        MAIN_ACTIVITY_TEMPLATE.format(package_name=args.package),
    )
    assets_dir = project_dir / "app" / "src" / "main" / "assets"
    if assets_dir.exists():
        shutil.rmtree(assets_dir)
    prepare_assets(source, assets_dir, args.entry)
    write_text(
        project_dir / "app" / "src" / "main" / "res" / "values" / "styles.xml",
        STYLES_XML,
    )
    return project_dir


def find_gradle(explicit_gradle: str) -> str:
    if explicit_gradle:
        return explicit_gradle

    executable = "gradle.bat" if os.name == "nt" else "gradle"
    gradle = shutil.which(executable) or shutil.which("gradle")
    if gradle:
        return gradle

    home = Path.home()
    candidates = sorted(
        (home / ".gradle" / "wrapper" / "dists").glob("gradle-*-bin/*/gradle-*/bin/gradle.bat"),
        reverse=True,
    )
    if candidates:
        return str(candidates[0])

    raise SystemExit(
        "Gradle was not found. Install Gradle, add it to PATH, pass "
        "--gradle, or rerun with --no-build to only generate the project."
    )


def find_java_home(explicit_java_home: str) -> str:
    if explicit_java_home:
        return explicit_java_home
    if os.environ.get("JAVA_HOME"):
        return os.environ["JAVA_HOME"]

    candidates = [
        Path("C:/Program Files/Android/Android Studio/jbr"),
        Path("C:/Program Files/Java"),
    ]
    for candidate in candidates:
        if candidate.is_dir():
            if (candidate / "bin" / "java.exe").is_file():
                return str(candidate)
            java_dirs = sorted(candidate.glob("*/bin/java.exe"), reverse=True)
            if java_dirs:
                return str(java_dirs[0].parent.parent)
    return ""


def find_android_sdk(explicit_sdk: str) -> str:
    if explicit_sdk:
        return explicit_sdk
    for key in ("ANDROID_HOME", "ANDROID_SDK_ROOT"):
        if os.environ.get(key):
            return os.environ[key]

    local_app_data = os.environ.get("LOCALAPPDATA")
    if local_app_data:
        candidate = Path(local_app_data) / "Android" / "Sdk"
        if candidate.is_dir():
            return str(candidate)
    return ""


def build_apk(args: argparse.Namespace, project_dir: Path) -> Path:
    gradle = find_gradle(args.gradle)
    command = [gradle, ":app:assembleDebug"]
    print("Running:", " ".join(command), flush=True)

    env = os.environ.copy()
    java_home = find_java_home(args.java_home)
    android_sdk = find_android_sdk(args.android_sdk)
    if java_home:
        env["JAVA_HOME"] = java_home
    if android_sdk:
        env["ANDROID_HOME"] = android_sdk
        env["ANDROID_SDK_ROOT"] = android_sdk

    subprocess.run(command, cwd=project_dir, check=True, env=env)

    apk_path = project_dir / "app" / "build" / "outputs" / "apk" / "debug" / "app-debug.apk"
    if not apk_path.is_file():
        raise SystemExit(f"Gradle finished, but APK was not found: {apk_path}")

    if args.apk:
        destination = Path(args.apk).resolve()
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(apk_path, destination)
        return destination

    return apk_path


def main() -> int:
    interactive = len(sys.argv) == 1 and sys.stdin.isatty()

    try:
        if interactive:
            args, source = interactive_args()
        else:
            args = parse_args()
            source = read_source(args)

        ensure_safe_package_name(args.package)

        project_dir = generate_project(args, source)
        print(f"Android project generated: {project_dir}", flush=True)

        if args.no_build:
            print("Skipped APK build.")
            return 0

        try:
            apk_path = build_apk(args, project_dir)
        except subprocess.CalledProcessError as exc:
            print(f"Gradle failed with exit code {exc.returncode}.", file=sys.stderr)
            return exc.returncode

        print(f"APK created: {apk_path}")
        return 0
    finally:
        if interactive:
            input("Enterキーで閉じます...")


if __name__ == "__main__":
    raise SystemExit(main())
